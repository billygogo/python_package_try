def add_one(number):
    return number + 1


def thankyou():
    return "Python 세상으로 첫번째 여행을 잘 마무리했네요. 당신의 첫걸음을 응원합니다. keep going~"
